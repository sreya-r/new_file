MYSQL_CONFIG = {
    'host': 'localhost',
    'user': 'sreya',
    'password': 'sreya',
    'database': 'sports_inventory',
    'port': 3306
}